package uk.ac.ucl.comp2010.bestgroup.AST;

public class ReallyDodgyStatementWrapper extends DecNode {
	public StatementNode s;
	public ReallyDodgyStatementWrapper(StatementNode s) {
		this.s = s;
	}
}
