package uk.ac.ucl.comp2010.bestgroup.AST;

public abstract class DecNode extends Node{}
