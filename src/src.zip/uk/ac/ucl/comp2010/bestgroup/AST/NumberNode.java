package uk.ac.ucl.comp2010.bestgroup.AST;

public abstract class NumberNode extends ExprNode{}
