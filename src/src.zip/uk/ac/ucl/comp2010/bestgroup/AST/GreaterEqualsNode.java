package uk.ac.ucl.comp2010.bestgroup.AST;

public class GreaterEqualsNode extends OperationNode{
	public GreaterEqualsNode(ExprNode l, ExprNode r) {
		super(l, r);
	}
}
