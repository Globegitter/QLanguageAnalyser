package uk.ac.ucl.comp2010.bestgroup.AST;

public class NotNode extends OperationNode{
	public NotNode(ExprNode v) {
		super(v);
	}
}
