package uk.ac.ucl.comp2010.bestgroup.AST;

public class FloatNode extends NumberNode{
	public float value;
	public FloatNode(float value) {
		this.value = value;
	}
}
