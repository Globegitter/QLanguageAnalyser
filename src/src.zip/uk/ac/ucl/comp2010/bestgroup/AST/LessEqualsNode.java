package uk.ac.ucl.comp2010.bestgroup.AST;

public class LessEqualsNode extends OperationNode{
	public LessEqualsNode(ExprNode l, ExprNode r) {
		super(l, r);
	}
}
