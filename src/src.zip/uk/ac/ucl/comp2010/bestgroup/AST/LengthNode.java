package uk.ac.ucl.comp2010.bestgroup.AST;

public class LengthNode extends ExprNode{
	String sequence;
	public LengthNode(String sequence) {
		this.sequence = sequence;
	}
}
