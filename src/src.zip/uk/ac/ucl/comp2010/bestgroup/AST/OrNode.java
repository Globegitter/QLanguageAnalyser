package uk.ac.ucl.comp2010.bestgroup.AST;

public class OrNode extends OperationNode{
	public OrNode(ExprNode l, ExprNode r) {
		super(l, r);
	}
}
