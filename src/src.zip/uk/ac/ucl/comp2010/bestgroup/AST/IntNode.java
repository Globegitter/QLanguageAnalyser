package uk.ac.ucl.comp2010.bestgroup.AST;

public class IntNode extends NumberNode{
	public int value;
	public IntNode(int value) {
		this.value = value;
	}
}
