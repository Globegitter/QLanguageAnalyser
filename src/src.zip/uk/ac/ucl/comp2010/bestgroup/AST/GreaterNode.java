package uk.ac.ucl.comp2010.bestgroup.AST;

public class GreaterNode extends OperationNode{
	public GreaterNode(ExprNode l, ExprNode r) {
		super(l, r);
	}
}
