package uk.ac.ucl.comp2010.bestgroup.AST;

public class MinusNode extends OperationNode{
	public MinusNode(ExprNode l, ExprNode r) {
		super(l, r);
	}
}
