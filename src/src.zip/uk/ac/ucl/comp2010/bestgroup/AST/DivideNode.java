package uk.ac.ucl.comp2010.bestgroup.AST;

public class DivideNode extends OperationNode{
	public DivideNode(ExprNode l, ExprNode r) {
		super(l, r);
	}
}
