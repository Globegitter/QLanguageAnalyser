package uk.ac.ucl.comp2010.bestgroup.AST;

public class PlusNode extends OperationNode{
	public PlusNode(ExprNode l, ExprNode r) {
		super(l, r);
	}
}
