package uk.ac.ucl.comp2010.bestgroup.AST;

public class VarExprNode extends ExprNode {
	public String id;
	public VarExprNode(String id) {
		this.id = id;
	}
}
