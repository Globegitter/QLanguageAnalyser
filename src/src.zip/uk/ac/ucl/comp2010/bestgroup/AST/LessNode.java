package uk.ac.ucl.comp2010.bestgroup.AST;

public class LessNode extends OperationNode{
	public LessNode(ExprNode l, ExprNode r) {
		super(l, r);
	}
}
