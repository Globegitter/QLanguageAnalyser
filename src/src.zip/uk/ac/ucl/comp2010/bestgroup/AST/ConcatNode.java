package uk.ac.ucl.comp2010.bestgroup.AST;

public class ConcatNode extends OperationNode{
	public ConcatNode(ExprNode l, ExprNode r) {
		super(l, r);
	}
}
