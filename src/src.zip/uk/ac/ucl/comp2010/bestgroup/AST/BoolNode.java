package uk.ac.ucl.comp2010.bestgroup.AST;

public class BoolNode extends OperationNode{
	public boolean value;
	public BoolNode(boolean value) {
		this.value = value;
	}
}
