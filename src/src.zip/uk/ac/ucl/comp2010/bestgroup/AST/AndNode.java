package uk.ac.ucl.comp2010.bestgroup.AST;

public class AndNode extends OperationNode{
	public AndNode(ExprNode l, ExprNode r) {
		super(l, r);
	}
}
