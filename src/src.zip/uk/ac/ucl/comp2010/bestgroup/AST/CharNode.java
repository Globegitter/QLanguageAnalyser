package uk.ac.ucl.comp2010.bestgroup.AST;

public class CharNode extends OperationNode{
	public char value;
	public CharNode(char value) {
		this.value = value;
	}
}
