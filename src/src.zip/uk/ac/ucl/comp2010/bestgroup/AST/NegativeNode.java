package uk.ac.ucl.comp2010.bestgroup.AST;

public class NegativeNode extends OperationNode{
	public NegativeNode(ExprNode v) {
		super(v);
	}
}
