package uk.ac.ucl.comp2010.bestgroup.AST;

public class TimesNode extends OperationNode{
	public TimesNode(ExprNode l, ExprNode r) {
		super(l, r);
	}
}
