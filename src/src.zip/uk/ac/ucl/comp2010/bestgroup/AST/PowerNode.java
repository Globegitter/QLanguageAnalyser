package uk.ac.ucl.comp2010.bestgroup.AST;

public class PowerNode extends OperationNode{
	public PowerNode(ExprNode l, ExprNode r) {
		super(l, r);
	}
}
