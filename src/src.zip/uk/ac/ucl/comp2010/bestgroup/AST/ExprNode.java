package uk.ac.ucl.comp2010.bestgroup.AST;

public class ExprNode extends Node{}
